import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Users } from '../models/users';
import { UsersService } from '../users.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {


  result:any
  user:Users=new Users()

  constructor(private service:UsersService,private router:Router) { }

  ngOnInit(): void {
  }

  addUser(){
    let res=this.service.registerUser(this.user);
    res.subscribe((data)=>{
      if(data!=null){
        this.router.navigateByUrl("login")
      }else{

      }
    })
  }

}
