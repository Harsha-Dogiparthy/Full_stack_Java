import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Flights } from './models/flights';

@Injectable({
  providedIn: 'root'
})
export class FlightserviceService {

  constructor(private http:HttpClient) { }

  public findAllFlights(){
    return this.http.get('http://localhost:8081/flights/all')
  }
  public newFlightService(f:Flights){
    return this.http.post('http://localhost:8081/flights/add',f)
  }

  public deleteFlightService(flightId:any){
    return this.http.delete('http://localhost:8081/flights/delete/'+flightId)
  }

  public findSearchFlight(flightId:any,from:String,to:String){
    return this.http.get('http://localhost:8081/flights/queryflight/'+flightId+'/'+from+'/'+to)
  }
}
