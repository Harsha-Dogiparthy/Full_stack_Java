import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { DeleteflightsComponent } from './deleteflights/deleteflights.component';
import { DeleteusersComponent } from './deleteusers/deleteusers.component';
import { DisplayusersComponent } from './displayusers/displayusers.component';
import { FlightsearchComponent } from './flightsearch/flightsearch.component';
import { LoginComponent } from './login/login.component';
import { NewflightsComponent } from './newflights/newflights.component';
import { RegisterComponent } from './register/register.component';
import { UserhomeComponent } from './userhome/userhome.component';

const routes: Routes = [
  {path:"login", component:LoginComponent},
  {path:"register", component:RegisterComponent},
  {path:"ahome", component:AdminhomeComponent},
  {path:"uhome", component:UserhomeComponent},
  {path:"users", component:DisplayusersComponent},
  {path:"dusers", component:DeleteusersComponent},
  {path:"dflight", component:DeleteflightsComponent},
  {path:"nservice", component: NewflightsComponent},
  {path:"search", component: FlightsearchComponent},
  {path:"",redirectTo:"/login",pathMatch:"full"},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
