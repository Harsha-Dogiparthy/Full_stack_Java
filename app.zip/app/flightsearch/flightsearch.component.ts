import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FlightserviceService } from '../flightservice.service';

@Component({
  selector: 'app-flightsearch',
  templateUrl: './flightsearch.component.html',
  styleUrls: ['./flightsearch.component.css']
})
export class FlightsearchComponent implements OnInit {

  flightId:any
  from:string=""
  to:String=""

  flights:any

  constructor(private fService:FlightserviceService,private root:Router) { }

  ngOnInit(): void {
    let res=this.fService.findAllFlights()
    res.subscribe((data)=>this.flights=data)
  }

  onSearch(){

    let res=this.fService.findSearchFlight(this.flightId?this.flightId:1,this.from?this.from:'k',this.to?this.to:'n')
    res.subscribe((data)=>this.flights=data)
  }


}
