import { Component, OnInit } from '@angular/core';
import { UsersService } from '../users.service';

@Component({
  selector: 'app-displayusers',
  templateUrl: './displayusers.component.html',
  styleUrls: ['./displayusers.component.css']
})
export class DisplayusersComponent implements OnInit {

  constructor(private service:UsersService) { }

  users:any

  ngOnInit(): void {
    let res=this.service.findUsers()
    res.subscribe((data)=>this.users=data);
  }

}
