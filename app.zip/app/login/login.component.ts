import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UsersService } from '../users.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userid:string=""
  pass:string=""
  userForm = new FormGroup({
    userid: new FormControl("",[Validators.minLength(4),Validators.maxLength(8)]),
    pass: new FormControl("",[Validators.minLength(4),Validators.maxLength(12)])
});


  constructor(private service:UsersService,private router:Router) { }

  ngOnInit(): void {

  }

  logIn(){
    let res=this.service.validateUser(this.userForm.get("userid")?.value,this.userForm.get("pass")?.value)
    res.subscribe((data:any)=>{
      if(data['role']==='admin'){
            this.router.navigateByUrl('ahome')
          }else{
            this.router.navigateByUrl('uhome')
          }
    })
  }

}
