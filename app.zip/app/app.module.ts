import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { UsersService } from './users.service';
import { RegisterComponent } from './register/register.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { UserhomeComponent } from './userhome/userhome.component';
import { UsermenuComponent } from './usermenu/usermenu.component';
import { AdminmenuComponent } from './adminmenu/adminmenu.component';
import { DisplayusersComponent } from './displayusers/displayusers.component';
import { DeleteusersComponent } from './deleteusers/deleteusers.component';
import { NewflightsComponent } from './newflights/newflights.component';
import { DeleteflightsComponent } from './deleteflights/deleteflights.component';
import { FlightsearchComponent } from './flightsearch/flightsearch.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    AdminhomeComponent,
    UserhomeComponent,
    UsermenuComponent,
    AdminmenuComponent,
    DisplayusersComponent,
    DeleteusersComponent,
    NewflightsComponent,
    DeleteflightsComponent,
    FlightsearchComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    NgbModule,
    HttpClientModule
  ],
  providers: [UsersService,NewflightsComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
