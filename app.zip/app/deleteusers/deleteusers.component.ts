import { Component, OnInit } from '@angular/core';
import { UsersService } from '../users.service';

@Component({
  selector: 'app-deleteusers',
  templateUrl: './deleteusers.component.html',
  styleUrls: ['./deleteusers.component.css']
})
export class DeleteusersComponent implements OnInit {

  constructor(private service:UsersService) { }

  users:any

  ngOnInit(): void {
    let res=this.service.findUsers()
    res.subscribe((data)=>this.users=data);
  }

  deleteUser(u:any){
    let res=this.service.deleteUser(u)
    res.subscribe((data)=>{
      console.log(data)
      this.ngOnInit()
    })
  }
}
