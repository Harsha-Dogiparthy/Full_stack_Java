import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FlightserviceService } from '../flightservice.service';
import { Flights } from '../models/flights';

@Component({
  selector: 'app-newflights',
  templateUrl: './newflights.component.html',
  styleUrls: ['./newflights.component.css']
})
export class NewflightsComponent implements OnInit {


  flights:Flights=new Flights()
  constructor(private fService:FlightserviceService,private router:Router) { }

  ngOnInit(): void {

  }

  addFlight(){
    let res=this.fService.newFlightService(this.flights)
    res.subscribe((data)=>{
      if(data!=null){
        this.router.navigateByUrl("users")
      }
    })
  }
}
