export class Users{
  userId:string=""
  pass:string=""
  name:string=""
  role:string=""
}
