export class Flights{
  flightId:any="";
	airlineId:any="";
	airlinename:String="";
	fromLocation:String="";
	toLocation:String="";
	departureTime:any="";
	arrivalTime:any="";
	duration:String="";
	seats:any="";
}
