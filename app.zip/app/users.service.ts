import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Users } from './models/users';

@Injectable({
  providedIn: 'root'
})

export class UsersService {

  constructor(private http:HttpClient) { }

  public validateUser(userId:String,pass:String){
    return this.http.get('http://localhost:8082/users/validate/'+userId+"/"+pass)
  }

  public registerUser(u:Users){
    return this.http.post('http://localhost:8082/users/register',u)
  }

  public findUsers(){
    return this.http.get('http://localhost:8082/users/all')
  }

  public deleteUser(userId:any){
    return this.http.delete('http://localhost:8082/users/delete/'+userId)
  }
}
