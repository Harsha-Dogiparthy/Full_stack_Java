import { Component, OnInit } from '@angular/core';
import { FlightserviceService } from '../flightservice.service';

@Component({
  selector: 'app-userhome',
  templateUrl: './userhome.component.html',
  styleUrls: ['./userhome.component.css']
})
export class UserhomeComponent implements OnInit {

  constructor(private fService:FlightserviceService) { }

  flights:any
  ngOnInit(): void {
    let res=this.fService.findAllFlights()
    res.subscribe((data)=>this.flights=data)
  }

}
